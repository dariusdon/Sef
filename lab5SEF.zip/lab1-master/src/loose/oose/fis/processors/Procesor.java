package loose.oose.fis.processors;

import loose.oose.fis.documents.Document;

import java.util.ArrayList;

public interface Procesor {
    int proceseaza(ArrayList<Document> documente);
}
